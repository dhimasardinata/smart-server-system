#include "Config.h"

namespace {
constexpr const char* DEFAULT_ADMIN_HASH =
    "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4";  // 1234
constexpr const char* DEFAULT_DEVICE_ID = "esp32-smart-server-01";
constexpr const char* DEFAULT_GSCRIPT_URL =
    "https://script.google.com/macros/s/AKfycbxVuisohtU0X2y6SBJhpR7stwr54dERGWv8wgq9KsjWhxZb-eH541N9pq33luIBhrWH4g/exec";

constexpr const char* LEGACY_WIFI_NETWORKS = "wifiNetworks";
constexpr const char* LEGACY_USERS = "userCredentials";
constexpr const char* LEGACY_SSID = "ssid";
constexpr const char* LEGACY_PASSWORD = "password";
constexpr const char* LEGACY_USER_ID = "userId";
constexpr const char* LEGACY_DISPLAY_NAME = "displayName";
constexpr const char* LEGACY_PIN_HASH = "pinHash";
constexpr const char* LEGACY_SENSOR_INTERVAL = "sensorReadIntervalSec";
constexpr const char* LEGACY_CLOUD_INTERVAL = "cloudSendIntervalSec";
constexpr const char* LEGACY_WARN_THRESHOLD = "warnThreshold";
constexpr const char* LEGACY_STAGE2_THRESHOLD = "stage2Threshold";
constexpr const char* LEGACY_FAN1_BASELINE = "fan1BaselineOn";
constexpr const char* LEGACY_MAX_FAILED = "maxFail";
constexpr const char* LEGACY_KEYPAD_LOCKOUT = "lockoutSecs";
constexpr const char* LEGACY_SOLENOID_UNLOCK = "unlockSecs";
constexpr const char* LEGACY_GOOGLE_SCRIPT_URL = "googleScriptUrl";
constexpr const char* LEGACY_DEVICE_ID = "deviceId";

template <typename TContainer>
JsonVariantConst getField(const TContainer& container, const char* primary,
                          const char* legacy, bool* usedLegacy = nullptr) {
  JsonVariantConst value = container[primary];
  if (!value.isNull()) return value;
  if (legacy == nullptr) return JsonVariantConst();

  value = container[legacy];
  if (!value.isNull() && usedLegacy != nullptr) *usedLegacy = true;
  return value;
}

template <typename TValue, typename TContainer>
bool readField(const TContainer& container, const char* primary,
               const char* legacy, TValue& out, bool* usedLegacy = nullptr) {
  JsonVariantConst value = getField(container, primary, legacy, usedLegacy);
  if (value.isNull()) return false;
  out = value.as<TValue>();
  return true;
}

template <typename TContainer>
bool readBoolField(const TContainer& container, const char* primary,
                   const char* legacy, bool& out,
                   bool* usedLegacy = nullptr) {
  JsonVariantConst value = getField(container, primary, legacy, usedLegacy);
  if (value.isNull()) return false;

  if (value.is<bool>()) {
    out = value.as<bool>();
    return true;
  }
  if (value.is<const char*>()) {
    String text = value.as<String>();
    text.trim();
    text.toLowerCase();
    if (text == "true" || text == "1") {
      out = true;
      return true;
    }
    if (text == "false" || text == "0") {
      out = false;
      return true;
    }
  }
  if (value.is<int>() || value.is<long>() || value.is<unsigned int>() ||
      value.is<uint32_t>()) {
    out = value.as<long>() != 0;
    return true;
  }

  return false;
}

template <typename TContainer>
JsonArrayConst readArrayField(const TContainer& container, const char* primary,
                              const char* legacy,
                              bool* usedLegacy = nullptr) {
  JsonVariantConst value = getField(container, primary, legacy, usedLegacy);
  if (value.is<JsonArrayConst>()) return value.as<JsonArrayConst>();
  return JsonArrayConst();
}
}  // namespace

AppConfig::AppConfig() {
  for (auto& network : wifiNetworks) {
    network.ssid = "";
    network.password = "";
    network.enabled = false;
  }

  for (auto& user : users) {
    user.userId = "";
    user.displayName = "";
    user.pinHash = "";
    user.enabled = false;
  }

  users[0].userId = "admin";
  users[0].displayName = "Administrator";
  users[0].pinHash = DEFAULT_ADMIN_HASH;
  users[0].enabled = true;

  sensorReadIntervalSec = 5;
  cloudSendIntervalSec = 60;
  warnThresholdC = 27.0f;
  stage2ThresholdC = 28.0f;
  fan1BaselineOn = true;
  maxFailedAttempts = 3;
  keypadLockoutSec = 120;
  solenoidUnlockSec = 10;
  googleScriptUrl = DEFAULT_GSCRIPT_URL;
  deviceId = DEFAULT_DEVICE_ID;
}

ConfigManager::ConfigManager(const char* filename) : _filename(filename) {}

bool ConfigManager::begin() {
  if (!LittleFS.begin(false)) {
    Serial.println(F("LittleFS mount failed, formatting"));
    if (!LittleFS.format()) {
      Serial.println(F("LittleFS format failed"));
      return false;
    }
    if (!LittleFS.begin(false)) {
      Serial.println(F("LittleFS mount failed after format"));
      return false;
    }
  }
  Serial.println(F("LittleFS mounted"));
  return load();
}

bool ConfigManager::resetToDefaultsAndSave() {
  data = AppConfig();
  return save();
}

bool ConfigManager::load() {
  File file = LittleFS.open(_filename, "r");
  if (!file) {
    Serial.println(F("Config missing, creating defaults"));
    return resetToDefaultsAndSave();
  }

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, file);
  file.close();

  if (err) {
    Serial.printf("Config parse error: %s. Resetting defaults.\n", err.c_str());
    return resetToDefaultsAndSave();
  }

  data = AppConfig();

  bool recognized = false;
  bool migrated = false;

  size_t i = 0;
  for (JsonObjectConst net :
       readArrayField(doc, ConfigKeys::WIFI_NETWORKS, LEGACY_WIFI_NETWORKS,
                      &migrated)) {
    if (i >= MAX_WIFI_NETWORKS) break;

    WiFiCredential network;
    network.enabled = true;
    readField(net, ConfigKeys::SSID, LEGACY_SSID, network.ssid, &migrated);
    readField(net, ConfigKeys::PASSWORD, LEGACY_PASSWORD, network.password,
              &migrated);
    readBoolField(net, ConfigKeys::ENABLED, "enabled", network.enabled,
                  &migrated);
    if (network.ssid.length() == 0) continue;

    data.wifiNetworks[i++] = network;
    recognized = true;
  }

  i = 0;
  for (JsonObjectConst user :
       readArrayField(doc, ConfigKeys::USERS, LEGACY_USERS, &migrated)) {
    if (i >= MAX_USERS) break;

    UserCredential credential;
    credential.enabled = true;
    readField(user, ConfigKeys::USER_ID, LEGACY_USER_ID, credential.userId,
              &migrated);
    readField(user, ConfigKeys::DISPLAY_NAME, LEGACY_DISPLAY_NAME,
              credential.displayName, &migrated);
    readField(user, ConfigKeys::PIN_HASH, LEGACY_PIN_HASH, credential.pinHash,
              &migrated);
    readBoolField(user, ConfigKeys::ENABLED, "enabled", credential.enabled,
                  &migrated);
    if (credential.userId.length() == 0) continue;

    data.users[i++] = credential;
    recognized = true;
  }

  recognized |= readField(doc, ConfigKeys::SENSOR_INTERVAL,
                          LEGACY_SENSOR_INTERVAL, data.sensorReadIntervalSec,
                          &migrated);
  recognized |= readField(doc, ConfigKeys::CLOUD_INTERVAL,
                          LEGACY_CLOUD_INTERVAL, data.cloudSendIntervalSec,
                          &migrated);
  recognized |= readField(doc, ConfigKeys::WARN_THRESHOLD,
                          LEGACY_WARN_THRESHOLD, data.warnThresholdC,
                          &migrated);
  recognized |= readField(doc, ConfigKeys::STAGE2_THRESHOLD,
                          LEGACY_STAGE2_THRESHOLD, data.stage2ThresholdC,
                          &migrated);
  recognized |= readBoolField(doc, ConfigKeys::FAN1_BASELINE,
                              LEGACY_FAN1_BASELINE, data.fan1BaselineOn,
                              &migrated);
  recognized |= readField(doc, ConfigKeys::MAX_FAILED, LEGACY_MAX_FAILED,
                          data.maxFailedAttempts, &migrated);
  recognized |= readField(doc, ConfigKeys::KEYPAD_LOCKOUT,
                          LEGACY_KEYPAD_LOCKOUT, data.keypadLockoutSec,
                          &migrated);
  recognized |= readField(doc, ConfigKeys::SOLENOID_UNLOCK,
                          LEGACY_SOLENOID_UNLOCK, data.solenoidUnlockSec,
                          &migrated);
  recognized |= readField(doc, ConfigKeys::GOOGLE_SCRIPT_URL,
                          LEGACY_GOOGLE_SCRIPT_URL, data.googleScriptUrl,
                          &migrated);
  recognized |= readField(doc, ConfigKeys::DEVICE_ID, LEGACY_DEVICE_ID,
                          data.deviceId, &migrated);

  if (!recognized) {
    Serial.println(F("Config schema unrecognized. Resetting defaults."));
    return resetToDefaultsAndSave();
  }

  bool repaired = false;
  if (data.googleScriptUrl.length() == 0) {
    data.googleScriptUrl = DEFAULT_GSCRIPT_URL;
    repaired = true;
  }
  if (data.deviceId.length() == 0) {
    data.deviceId = DEFAULT_DEVICE_ID;
    repaired = true;
  }
  if (getUserCount() == 0) {
    data.users[0].userId = "admin";
    data.users[0].displayName = "Administrator";
    data.users[0].pinHash = DEFAULT_ADMIN_HASH;
    data.users[0].enabled = true;
    repaired = true;
    Serial.println(F("Config has no users. Restored default admin."));
  }

  if (migrated) {
    Serial.println(F("Config legacy/missing fields migrated to current schema."));
  }

  if (migrated || repaired) {
    save();
  }

  Serial.println(F("Config loaded"));
  return true;
}

bool ConfigManager::save() {
  static constexpr const char* TEMP_FILENAME = "/config.tmp";
  JsonDocument doc;

  JsonArray wifiArr = doc[ConfigKeys::WIFI_NETWORKS].to<JsonArray>();
  for (const auto& network : data.wifiNetworks) {
    if (network.ssid.length() == 0) continue;
    JsonObject net = wifiArr.add<JsonObject>();
    net[ConfigKeys::SSID] = network.ssid;
    net[ConfigKeys::PASSWORD] = network.password;
    net[ConfigKeys::ENABLED] = network.enabled;
  }

  JsonArray usersArr = doc[ConfigKeys::USERS].to<JsonArray>();
  for (const auto& user : data.users) {
    if (user.userId.length() == 0) continue;
    JsonObject item = usersArr.add<JsonObject>();
    item[ConfigKeys::USER_ID] = user.userId;
    item[ConfigKeys::DISPLAY_NAME] = user.displayName;
    item[ConfigKeys::PIN_HASH] = user.pinHash;
    item[ConfigKeys::ENABLED] = user.enabled;
  }

  doc[ConfigKeys::SENSOR_INTERVAL] = data.sensorReadIntervalSec;
  doc[ConfigKeys::CLOUD_INTERVAL] = data.cloudSendIntervalSec;
  doc[ConfigKeys::WARN_THRESHOLD] = data.warnThresholdC;
  doc[ConfigKeys::STAGE2_THRESHOLD] = data.stage2ThresholdC;
  doc[ConfigKeys::FAN1_BASELINE] = data.fan1BaselineOn;
  doc[ConfigKeys::MAX_FAILED] = data.maxFailedAttempts;
  doc[ConfigKeys::KEYPAD_LOCKOUT] = data.keypadLockoutSec;
  doc[ConfigKeys::SOLENOID_UNLOCK] = data.solenoidUnlockSec;
  doc[ConfigKeys::GOOGLE_SCRIPT_URL] = data.googleScriptUrl;
  doc[ConfigKeys::DEVICE_ID] = data.deviceId;

  File file = LittleFS.open(TEMP_FILENAME, "w");
  if (!file) {
    Serial.println(F("Failed to open config file for writing"));
    return false;
  }

  const size_t written = serializeJson(doc, file);
  file.flush();
  file.close();

  if (written == 0) {
    Serial.println(F("Failed to serialize config"));
    LittleFS.remove(TEMP_FILENAME);
    return false;
  }

  LittleFS.remove(_filename);
  if (!LittleFS.rename(TEMP_FILENAME, _filename)) {
    Serial.println(F("Failed to replace config file"));
    LittleFS.remove(TEMP_FILENAME);
    return false;
  }

  Serial.printf("Config saved: wifi=%u users=%u\n",
                static_cast<unsigned>(getWiFiCount()),
                static_cast<unsigned>(getUserCount()));
  return true;
}

bool ConfigManager::formatFileSystem() {
  Serial.println(F("Formatting LittleFS and restoring defaults"));
  LittleFS.end();

  if (!LittleFS.format()) {
    Serial.println(F("LittleFS format failed"));
    return false;
  }
  if (!LittleFS.begin(false)) {
    Serial.println(F("LittleFS remount failed after format"));
    return false;
  }

  data = AppConfig();
  return save();
}

bool ConfigManager::addWiFi(const String& ssid, const String& password) {
  for (auto& network : data.wifiNetworks) {
    if (network.ssid == ssid) {
      network.password = password;
      network.enabled = true;
      return save();
    }
  }

  for (auto& network : data.wifiNetworks) {
    if (network.ssid.length() == 0) {
      network.ssid = ssid;
      network.password = password;
      network.enabled = true;
      return save();
    }
  }
  return false;
}

bool ConfigManager::removeWiFi(const String& ssid) {
  for (auto& network : data.wifiNetworks) {
    if (network.ssid == ssid) {
      network.ssid = "";
      network.password = "";
      network.enabled = false;
      return save();
    }
  }
  return false;
}

size_t ConfigManager::getWiFiCount() const {
  size_t count = 0;
  for (const auto& network : data.wifiNetworks) {
    if (network.ssid.length() > 0 && network.enabled) ++count;
  }
  return count;
}

void ConfigManager::clearAllWiFi() {
  for (auto& network : data.wifiNetworks) {
    network.ssid = "";
    network.password = "";
    network.enabled = false;
  }
  save();
}

bool ConfigManager::upsertUser(const UserCredential& user) {
  if (user.userId.length() == 0 || user.pinHash.length() == 0) return false;

  for (auto& existing : data.users) {
    if (existing.userId == user.userId) {
      existing.displayName = user.displayName;
      existing.pinHash = user.pinHash;
      existing.enabled = user.enabled;
      return save();
    }
  }

  for (auto& existing : data.users) {
    if (existing.userId.length() == 0) {
      existing = user;
      return save();
    }
  }
  return false;
}

bool ConfigManager::removeUser(const String& userId) {
  for (auto& user : data.users) {
    if (user.userId == userId) {
      if (user.enabled && getUserCount() <= 1) {
        Serial.println(F("Refusing to delete last enabled user"));
        return false;
      }
      user.userId = "";
      user.displayName = "";
      user.pinHash = "";
      user.enabled = false;
      return save();
    }
  }
  return false;
}

size_t ConfigManager::getUserCount() const {
  size_t count = 0;
  for (const auto& user : data.users) {
    if (user.userId.length() > 0 && user.enabled) ++count;
  }
  return count;
}

const UserCredential* ConfigManager::findUser(const String& userId) const {
  for (const auto& user : data.users) {
    if (user.userId == userId && user.enabled) return &user;
  }
  return nullptr;
}
